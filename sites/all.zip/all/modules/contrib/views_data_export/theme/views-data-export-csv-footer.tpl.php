<?php

/**
 * CSV files don't really have a footer.
 */